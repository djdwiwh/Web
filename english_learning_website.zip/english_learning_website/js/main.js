// Main JavaScript file for English Learning Website

// Initialize AOS (Animate On Scroll)
$(document).ready(function() {
    AOS.init({
        duration: 800,
        easing: 'ease-in-out',
        once: true,
        mirror: false
    });
    
    // Initialize tooltips
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });
    
    // Configure Toastr
    toastr.options = {
        "closeButton": true,
        "debug": false,
        "newestOnTop": true,
        "progressBar": true,
        "positionClass": "toast-top-right",
        "preventDuplicates": false,
        "onclick": null,
        "showDuration": "300",
        "hideDuration": "1000",
        "timeOut": "5000",
        "extendedTimeOut": "1000",
        "showEasing": "swing",
        "hideEasing": "linear",
        "showMethod": "fadeIn",
        "hideMethod": "fadeOut"
    };
});

// Welcome Toast Notification
function showWelcomeToast() {
    toastr.success('مرحباً بك في موقع تعلم الإنجليزية! ابدأ رحلتك التعليمية الآن.', 'أهلاً وسهلاً');
}

// Success Toast
function showSuccessToast(message, title = 'نجح') {
    toastr.success(message, title);
}

// Error Toast
function showErrorToast(message, title = 'خطأ') {
    toastr.error(message, title);
}

// Info Toast
function showInfoToast(message, title = 'معلومة') {
    toastr.info(message, title);
}

// Warning Toast
function showWarningToast(message, title = 'تحذير') {
    toastr.warning(message, title);
}

// Form Validation Functions
function validateEmail(email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
}

function validatePassword(password) {
    // Password should be at least 8 characters long
    return password.length >= 8;
}

function validateName(name) {
    // Name should be at least 2 characters long
    return name.trim().length >= 2;
}

// Register User Function
function registerUser() {
    const fullName = $('#fullName').val().trim();
    const email = $('#email').val().trim();
    const password = $('#password').val();
    const confirmPassword = $('#confirmPassword').val();
    
    // Reset previous validation states
    $('.form-control').removeClass('is-valid is-invalid');
    $('.invalid-feedback').remove();
    
    let isValid = true;
    
    // Validate Full Name
    if (!validateName(fullName)) {
        $('#fullName').addClass('is-invalid');
        $('#fullName').after('<div class="invalid-feedback">يجب أن يكون الاسم مكوناً من حرفين على الأقل</div>');
        isValid = false;
    } else {
        $('#fullName').addClass('is-valid');
    }
    
    // Validate Email
    if (!validateEmail(email)) {
        $('#email').addClass('is-invalid');
        $('#email').after('<div class="invalid-feedback">يرجى إدخال بريد إلكتروني صحيح</div>');
        isValid = false;
    } else {
        $('#email').addClass('is-valid');
    }
    
    // Validate Password
    if (!validatePassword(password)) {
        $('#password').addClass('is-invalid');
        $('#password').after('<div class="invalid-feedback">يجب أن تكون كلمة المرور مكونة من 8 أحرف على الأقل</div>');
        isValid = false;
    } else {
        $('#password').addClass('is-valid');
    }
    
    // Validate Confirm Password
    if (password !== confirmPassword) {
        $('#confirmPassword').addClass('is-invalid');
        $('#confirmPassword').after('<div class="invalid-feedback">كلمة المرور غير متطابقة</div>');
        isValid = false;
    } else if (confirmPassword.length > 0) {
        $('#confirmPassword').addClass('is-valid');
    }
    
    if (isValid) {
        // Simulate registration process
        const button = $('button[onclick="registerUser()"]');
        const originalText = button.text();
        
        button.html('<span class="loading"></span> جاري إنشاء الحساب...');
        button.prop('disabled', true);
        
        setTimeout(() => {
            button.html(originalText);
            button.prop('disabled', false);
            $('#registerModal').modal('hide');
            showSuccessToast('تم إنشاء حسابك بنجاح! يمكنك الآن تسجيل الدخول.', 'تم بنجاح');
            
            // Reset form
            $('#registerForm')[0].reset();
            $('.form-control').removeClass('is-valid is-invalid');
        }, 2000);
    }
}

// Login User Function
function loginUser() {
    const email = $('#loginEmail').val().trim();
    const password = $('#loginPassword').val();
    
    // Reset previous validation states
    $('.form-control').removeClass('is-valid is-invalid');
    $('.invalid-feedback').remove();
    
    let isValid = true;
    
    // Validate Email
    if (!validateEmail(email)) {
        $('#loginEmail').addClass('is-invalid');
        $('#loginEmail').after('<div class="invalid-feedback">يرجى إدخال بريد إلكتروني صحيح</div>');
        isValid = false;
    } else {
        $('#loginEmail').addClass('is-valid');
    }
    
    // Validate Password
    if (password.length === 0) {
        $('#loginPassword').addClass('is-invalid');
        $('#loginPassword').after('<div class="invalid-feedback">يرجى إدخال كلمة المرور</div>');
        isValid = false;
    } else {
        $('#loginPassword').addClass('is-valid');
    }
    
    if (isValid) {
        // Simulate login process
        const button = $('button[onclick="loginUser()"]');
        const originalText = button.text();
        
        button.html('<span class="loading"></span> جاري تسجيل الدخول...');
        button.prop('disabled', true);
        
        setTimeout(() => {
            button.html(originalText);
            button.prop('disabled', false);
            showSuccessToast('تم تسجيل الدخول بنجاح!', 'أهلاً بك');
            
            // Redirect to dashboard or update UI
            // window.location.href = 'dashboard.html';
        }, 2000);
    }
}

// Contact Form Submission
function submitContactForm() {
    const name = $('#contactName').val().trim();
    const email = $('#contactEmail').val().trim();
    const subject = $('#contactSubject').val().trim();
    const message = $('#contactMessage').val().trim();
    
    // Reset previous validation states
    $('.form-control').removeClass('is-valid is-invalid');
    $('.invalid-feedback').remove();
    
    let isValid = true;
    
    // Validate Name
    if (!validateName(name)) {
        $('#contactName').addClass('is-invalid');
        $('#contactName').after('<div class="invalid-feedback">يجب أن يكون الاسم مكوناً من حرفين على الأقل</div>');
        isValid = false;
    } else {
        $('#contactName').addClass('is-valid');
    }
    
    // Validate Email
    if (!validateEmail(email)) {
        $('#contactEmail').addClass('is-invalid');
        $('#contactEmail').after('<div class="invalid-feedback">يرجى إدخال بريد إلكتروني صحيح</div>');
        isValid = false;
    } else {
        $('#contactEmail').addClass('is-valid');
    }
    
    // Validate Subject
    if (subject.length < 3) {
        $('#contactSubject').addClass('is-invalid');
        $('#contactSubject').after('<div class="invalid-feedback">يجب أن يكون الموضوع مكوناً من 3 أحرف على الأقل</div>');
        isValid = false;
    } else {
        $('#contactSubject').addClass('is-valid');
    }
    
    // Validate Message
    if (message.length < 10) {
        $('#contactMessage').addClass('is-invalid');
        $('#contactMessage').after('<div class="invalid-feedback">يجب أن تكون الرسالة مكونة من 10 أحرف على الأقل</div>');
        isValid = false;
    } else {
        $('#contactMessage').addClass('is-valid');
    }
    
    if (isValid) {
        // Simulate form submission
        const button = $('button[onclick="submitContactForm()"]');
        const originalText = button.text();
        
        button.html('<span class="loading"></span> جاري الإرسال...');
        button.prop('disabled', true);
        
        setTimeout(() => {
            button.html(originalText);
            button.prop('disabled', false);
            showSuccessToast('تم إرسال رسالتك بنجاح! سنتواصل معك قريباً.', 'تم الإرسال');
            
            // Reset form
            $('#contactForm')[0].reset();
            $('.form-control').removeClass('is-valid is-invalid');
        }, 2000);
    }
}

// Load Course Details via Ajax
function loadCourseDetails(courseId) {
    // Simulate Ajax request
    $.ajax({
        url: '/api/courses/' + courseId,
        method: 'GET',
        beforeSend: function() {
            showInfoToast('جاري تحميل تفاصيل الدورة...', 'يرجى الانتظار');
        },
        success: function(data) {
            // Simulate successful response
            setTimeout(() => {
                $('#courseDetailsModal').modal('show');
                showSuccessToast('تم تحميل تفاصيل الدورة بنجاح!', 'تم التحميل');
            }, 1000);
        },
        error: function() {
            showErrorToast('حدث خطأ أثناء تحميل تفاصيل الدورة', 'خطأ في التحميل');
        }
    });
}

// Forgot Password Modal
function showForgotPasswordModal() {
    $('#forgotPasswordModal').modal('show');
}

// Reset Password Function
function resetPassword() {
    const email = $('#resetEmail').val().trim();
    
    if (!validateEmail(email)) {
        $('#resetEmail').addClass('is-invalid');
        $('#resetEmail').after('<div class="invalid-feedback">يرجى إدخال بريد إلكتروني صحيح</div>');
        return;
    }
    
    $('#resetEmail').addClass('is-valid');
    
    // Simulate password reset
    const button = $('button[onclick="resetPassword()"]');
    const originalText = button.text();
    
    button.html('<span class="loading"></span> جاري الإرسال...');
    button.prop('disabled', true);
    
    setTimeout(() => {
        button.html(originalText);
        button.prop('disabled', false);
        $('#forgotPasswordModal').modal('hide');
        showSuccessToast('تم إرسال رابط إعادة تعيين كلمة المرور إلى بريدك الإلكتروني', 'تم الإرسال');
        
        // Reset form
        $('#resetEmail').val('');
        $('#resetEmail').removeClass('is-valid is-invalid');
    }, 2000);
}

// Smooth Scrolling for Anchor Links
$('a[href^="#"]').on('click', function(event) {
    var target = $(this.getAttribute('href'));
    if (target.length) {
        event.preventDefault();
        $('html, body').stop().animate({
            scrollTop: target.offset().top - 100
        }, 1000);
    }
});

// Navbar Scroll Effect
$(window).scroll(function() {
    if ($(this).scrollTop() > 50) {
        $('.navbar').addClass('scrolled');
    } else {
        $('.navbar').removeClass('scrolled');
    }
});

// Course Filter Function
function filterCourses(level) {
    $('.course-card').hide();
    
    if (level === 'all') {
        $('.course-card').fadeIn();
    } else {
        $('.course-card[data-level="' + level + '"]').fadeIn();
    }
    
    // Update active filter button
    $('.filter-btn').removeClass('active');
    $('.filter-btn[data-filter="' + level + '"]').addClass('active');
}

// Search Courses Function
function searchCourses() {
    const searchTerm = $('#courseSearch').val().toLowerCase();
    
    $('.course-card').each(function() {
        const courseTitle = $(this).find('.card-title').text().toLowerCase();
        const courseDescription = $(this).find('.card-text').text().toLowerCase();
        
        if (courseTitle.includes(searchTerm) || courseDescription.includes(searchTerm)) {
            $(this).fadeIn();
        } else {
            $(this).fadeOut();
        }
    });
}

// Initialize Course Search
$(document).ready(function() {
    $('#courseSearch').on('input', searchCourses);
});

// Back to Top Button
$(window).scroll(function() {
    if ($(this).scrollTop() > 300) {
        $('#backToTop').fadeIn();
    } else {
        $('#backToTop').fadeOut();
    }
});

$('#backToTop').click(function() {
    $('html, body').animate({scrollTop: 0}, 800);
    return false;
});

// Preloader
$(window).on('load', function() {
    $('#preloader').fadeOut('slow');
});

// Error Handling for Images
$('img').on('error', function() {
    $(this).attr('src', '../images/placeholder.jpg');
});

// Dynamic Year in Footer
$(document).ready(function() {
    const currentYear = new Date().getFullYear();
    $('.current-year').text(currentYear);
});

