# هيكل موقع تعلم اللغة الإنجليزية

## الصفحات الرئيسية:

### 1. الصفحة الرئيسية (index.html)
- **Header**: شعار الموقع + قائمة التنقل
- **Hero Section**: عنوان رئيسي جذاب + وصف مختصر + زر البدء
- **Features Section**: مميزات الموقع (3-4 مميزات)
- **Courses Preview**: عرض سريع للدورات المتاحة
- **Testimonials**: آراء الطلاب (شريط صور متحرك)
- **Footer**: روابط مهمة + معلومات التواصل

### 2. صفحة حول الموقع (about.html)
- **Header**: نفس التصميم
- **About Section**: معلومات عن الموقع ورؤيته
- **Team Section**: فريق العمل
- **Mission & Vision**: الرسالة والرؤية
- **Footer**: نفس التصميم

### 3. صفحة الدورات (courses.html)
- **Header**: نفس التصميم
- **Courses Grid**: عرض الدورات باستخدام Grid Layout
- **Course Cards**: بطاقات تفاعلية للدورات
- **Filter Options**: خيارات تصفية الدورات
- **Footer**: نفس التصميم

### 4. صفحة التواصل (contact.html)
- **Header**: نفس التصميم
- **Contact Form**: نموذج تواصل مع التحقق من البيانات
- **Contact Info**: معلومات التواصل مع أيقونات Font Awesome
- **Map Section**: خريطة الموقع (اختيارية)
- **Footer**: نفس التصميم

### 5. صفحة تسجيل الدخول (login.html)
- **Header**: مبسط
- **Login Form**: نموذج تسجيل الدخول مع التحقق
- **Register Modal**: نافذة منبثقة لإنشاء حساب جديد
- **Forgot Password Modal**: نافذة منبثقة لاستعادة كلمة المرور

## الألوان المقترحة:
- **Primary**: #2563eb (أزرق)
- **Secondary**: #10b981 (أخضر)
- **Accent**: #f59e0b (برتقالي)
- **Background**: #f8fafc (رمادي فاتح)
- **Text**: #1e293b (رمادي داكن)

## الخطوط:
- **Primary Font**: 'Inter', sans-serif
- **Secondary Font**: 'Poppins', sans-serif

## المكتبات المستخدمة:
- Bootstrap 5
- jQuery 3.6
- Font Awesome 6
- WowSlider
- Toast Notification Library
- AOS (Animate On Scroll)

